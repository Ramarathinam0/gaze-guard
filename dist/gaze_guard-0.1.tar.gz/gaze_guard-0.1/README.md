# Gaze Guard 👁️

Gaze Guard is a Python library that controls AI responses based on user attention using the camera.

## Features
- Runs camera in background
- Detects if user is looking
- Helps AI respond only when needed

## Installation

pip install -r requirements.txt

## Usage

```python
from gaze_guard import AttentionController

controller = AttentionController()

if controller.is_user_attentive():
    print("User is looking")
else:
    print("User is not looking")